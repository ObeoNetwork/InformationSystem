package org.obeonetwork.sample.ui.manage.actions;

// Start of user code for import
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.obeonetwork.sample.ui.manage.forms.ManageCommentsForm;


import org.obeonetwork.sample.manage.IManageService;
import org.obeonetwork.sample.monitor.IMonitorService;


// End of user code for import


/**
 * Implementation of <strong>ManageComments Action</strong>
 * Scenario : Manage
 *
 */
public class ManageCommentsAction extends org.apache.struts.actions.DispatchAction {
    /**
     * Commons Logging instance.
     */
     private final static Log LOG = LogFactory.getLog(ManageCommentsAction.class);

    /**
     * Forward codes.
     */
	public final static String PAGE_SELF = "self"; //$NON-NLS-1$
	public final static String PAGE_DELETECOMMENT = "deleteComment"; //$NON-NLS-1$
	public final static String PAGE_UPDATECOMMENT = "updateComment"; //$NON-NLS-1$
//Start of user code user attributes
//End of user code
    /**
     * Process the specified HTTP request for <strong>init</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     * @return Forward setting with indirection forward name (see struts-config for real JSP name)
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward init(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting init");
		String returnCode = PAGE_SELF;
		ManageCommentsForm manageCommentsForm = (ManageCommentsForm)form;

		//Start of user code method init
		// TODO Write here the action code for init
		//End of user code

		LOG.debug("End init");	
		return mapping.findForward(returnCode);
	} 

    /**
     * Process if no event specified. Redirect to init.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     * @return Forward setting with indirection forward name (see struts-config for real JSP name)
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("No event specified. Redirect to init.");
		return init(mapping, form, request, response);
	} 

    /**
     * Process the specified HTTP request for <strong>updateComment</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward updateComment(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting updateComment");
		String returnCode = PAGE_SELF;
		ManageCommentsForm manageCommentsForm = (ManageCommentsForm)form;
		
		//Start of user code method updateComment
		// TODO Write here the action code for updateComment
		//End of user code

		LOG.debug("End updateComment");
		return mapping.findForward(returnCode);
	}
    /**
     * Process the specified HTTP request for <strong>deleteComment</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward deleteComment(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting deleteComment");
		String returnCode = PAGE_SELF;
		ManageCommentsForm manageCommentsForm = (ManageCommentsForm)form;
		
		//Start of user code method deleteComment
		// TODO Write here the action code for deleteComment
		//End of user code

		LOG.debug("End deleteComment");
		return mapping.findForward(returnCode);
	}
    /**
     * Process the specified HTTP request for <strong>viewComments</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward viewComments(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting viewComments");
		String returnCode = PAGE_SELF;
		ManageCommentsForm manageCommentsForm = (ManageCommentsForm)form;
		
		//Start of user code method viewComments
		// TODO Write here the action code for viewComments
		//End of user code

		LOG.debug("End viewComments");
		return mapping.findForward(returnCode);
	}

private IManageService manageService;
public void setManageService(IManageService manageService){
	this.manageService=manageService;
}
private IMonitorService monitorService;
public void setMonitorService(IMonitorService monitorService){
	this.monitorService=monitorService;
}


//Start of user code user methods
//End of user code

}