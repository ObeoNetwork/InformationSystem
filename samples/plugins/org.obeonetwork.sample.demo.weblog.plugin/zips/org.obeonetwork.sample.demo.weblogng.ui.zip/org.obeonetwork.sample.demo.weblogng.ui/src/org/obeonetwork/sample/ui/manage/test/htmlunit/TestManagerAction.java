package org.obeonetwork.sample.ui.manage.test.htmlunit;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.List;

import junit.framework.TestCase;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.*;

/**
 * HtmlUnit testing for <strong>Manager Form</strong>
 * Scenario : manage
 *
 */
public class TestManagerAction extends TestCase {

	/**
	 * initialize the TestCase.
	 * 
	 * @throws Exception if the test fails
	 */
	public void setUp() throws Exception {
		super.setUp();
		//Start of user code for setUp
		//End of user code
	}

	/**
	 * terminate the TestCase.
	 * 
	 * @throws Exception if the test fails
	 */
	public void tearDown() throws Exception {
		super.tearDown();
		//Start of user code for tearDown
		//End of user code
	}

	/**
	 * Constructor
	 */
	public TestManagerAction(String testName) {
		super(testName);
		//Start of user code for Constructor
		//End of user code
	}
	/**
	  * Regression test for "deleteUser" action of class ManagerAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManagerdeleteUserAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/manager?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManagerForm");
		final HtmlTextInput screenDeleteUser = (HtmlTextInput)form.getInputByName("screenDeleteUser");
		final HtmlTextInput screenManageComments = (HtmlTextInput)form.getInputByName("screenManageComments");
		final HtmlTextInput screenManageCategories = (HtmlTextInput)form.getInputByName("screenManageCategories");
		final HtmlTextInput screenManageTags = (HtmlTextInput)form.getInputByName("screenManageTags");
	    final HtmlSubmitInput deleteUser = (HtmlSubmitInput)form.getInputByName("deleteUser");
	    
	    assertEquals("screenDeleteUserscreenManageCommentsscreenManageCategoriesscreenManageTags", page1.getTitleText());

		//Start of user code for deleteUser action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)deleteUser.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "manageComments" action of class ManagerAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManagermanageCommentsAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/manager?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManagerForm");
		final HtmlTextInput screenDeleteUser = (HtmlTextInput)form.getInputByName("screenDeleteUser");
		final HtmlTextInput screenManageComments = (HtmlTextInput)form.getInputByName("screenManageComments");
		final HtmlTextInput screenManageCategories = (HtmlTextInput)form.getInputByName("screenManageCategories");
		final HtmlTextInput screenManageTags = (HtmlTextInput)form.getInputByName("screenManageTags");
	    final HtmlSubmitInput manageComments = (HtmlSubmitInput)form.getInputByName("manageComments");
	    
	    assertEquals("screenDeleteUserscreenManageCommentsscreenManageCategoriesscreenManageTags", page1.getTitleText());

		//Start of user code for manageComments action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)manageComments.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "manageCategories" action of class ManagerAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManagermanageCategoriesAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/manager?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManagerForm");
		final HtmlTextInput screenDeleteUser = (HtmlTextInput)form.getInputByName("screenDeleteUser");
		final HtmlTextInput screenManageComments = (HtmlTextInput)form.getInputByName("screenManageComments");
		final HtmlTextInput screenManageCategories = (HtmlTextInput)form.getInputByName("screenManageCategories");
		final HtmlTextInput screenManageTags = (HtmlTextInput)form.getInputByName("screenManageTags");
	    final HtmlSubmitInput manageCategories = (HtmlSubmitInput)form.getInputByName("manageCategories");
	    
	    assertEquals("screenDeleteUserscreenManageCommentsscreenManageCategoriesscreenManageTags", page1.getTitleText());

		//Start of user code for manageCategories action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)manageCategories.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "manageTags" action of class ManagerAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManagermanageTagsAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/manager?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManagerForm");
		final HtmlTextInput screenDeleteUser = (HtmlTextInput)form.getInputByName("screenDeleteUser");
		final HtmlTextInput screenManageComments = (HtmlTextInput)form.getInputByName("screenManageComments");
		final HtmlTextInput screenManageCategories = (HtmlTextInput)form.getInputByName("screenManageCategories");
		final HtmlTextInput screenManageTags = (HtmlTextInput)form.getInputByName("screenManageTags");
	    final HtmlSubmitInput manageTags = (HtmlSubmitInput)form.getInputByName("manageTags");
	    
	    assertEquals("screenDeleteUserscreenManageCommentsscreenManageCategoriesscreenManageTags", page1.getTitleText());

		//Start of user code for manageTags action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)manageTags.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	//Start of user code for other tests
	//End of user code
}