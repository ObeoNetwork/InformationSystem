package org.obeonetwork.sample.ui.monitoring.test.htmlunit;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.List;

import junit.framework.TestCase;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.*;

/**
 * HtmlUnit testing for <strong>Monitor Form</strong>
 * Scenario : monitoring
 *
 */
public class TestMonitorAction extends TestCase {

	/**
	 * initialize the TestCase.
	 * 
	 * @throws Exception if the test fails
	 */
	public void setUp() throws Exception {
		super.setUp();
		//Start of user code for setUp
		//End of user code
	}

	/**
	 * terminate the TestCase.
	 * 
	 * @throws Exception if the test fails
	 */
	public void tearDown() throws Exception {
		super.tearDown();
		//Start of user code for tearDown
		//End of user code
	}

	/**
	 * Constructor
	 */
	public TestMonitorAction(String testName) {
		super(testName);
		//Start of user code for Constructor
		//End of user code
	}
	/**
	  * Regression test for "seeUsers" action of class MonitorAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testMonitorseeUsersAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/monitoring/monitor?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("MonitorForm");
		final HtmlTextInput viewUsers = (HtmlTextInput)form.getInputByName("viewUsers");
		final HtmlTextInput viewComments = (HtmlTextInput)form.getInputByName("viewComments");
		final HtmlTextInput viewCategories = (HtmlTextInput)form.getInputByName("viewCategories");
		final HtmlTextInput viewTags = (HtmlTextInput)form.getInputByName("viewTags");
	    final HtmlSubmitInput seeUsers = (HtmlSubmitInput)form.getInputByName("seeUsers");
	    
	    assertEquals("viewUsersviewCommentsviewCategoriesviewTags", page1.getTitleText());

		//Start of user code for seeUsers action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)seeUsers.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "seeComments" action of class MonitorAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testMonitorseeCommentsAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/monitoring/monitor?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("MonitorForm");
		final HtmlTextInput viewUsers = (HtmlTextInput)form.getInputByName("viewUsers");
		final HtmlTextInput viewComments = (HtmlTextInput)form.getInputByName("viewComments");
		final HtmlTextInput viewCategories = (HtmlTextInput)form.getInputByName("viewCategories");
		final HtmlTextInput viewTags = (HtmlTextInput)form.getInputByName("viewTags");
	    final HtmlSubmitInput seeComments = (HtmlSubmitInput)form.getInputByName("seeComments");
	    
	    assertEquals("viewUsersviewCommentsviewCategoriesviewTags", page1.getTitleText());

		//Start of user code for seeComments action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)seeComments.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "seeCategories" action of class MonitorAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testMonitorseeCategoriesAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/monitoring/monitor?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("MonitorForm");
		final HtmlTextInput viewUsers = (HtmlTextInput)form.getInputByName("viewUsers");
		final HtmlTextInput viewComments = (HtmlTextInput)form.getInputByName("viewComments");
		final HtmlTextInput viewCategories = (HtmlTextInput)form.getInputByName("viewCategories");
		final HtmlTextInput viewTags = (HtmlTextInput)form.getInputByName("viewTags");
	    final HtmlSubmitInput seeCategories = (HtmlSubmitInput)form.getInputByName("seeCategories");
	    
	    assertEquals("viewUsersviewCommentsviewCategoriesviewTags", page1.getTitleText());

		//Start of user code for seeCategories action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)seeCategories.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "seeTags" action of class MonitorAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testMonitorseeTagsAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/monitoring/monitor?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("MonitorForm");
		final HtmlTextInput viewUsers = (HtmlTextInput)form.getInputByName("viewUsers");
		final HtmlTextInput viewComments = (HtmlTextInput)form.getInputByName("viewComments");
		final HtmlTextInput viewCategories = (HtmlTextInput)form.getInputByName("viewCategories");
		final HtmlTextInput viewTags = (HtmlTextInput)form.getInputByName("viewTags");
	    final HtmlSubmitInput seeTags = (HtmlSubmitInput)form.getInputByName("seeTags");
	    
	    assertEquals("viewUsersviewCommentsviewCategoriesviewTags", page1.getTitleText());

		//Start of user code for seeTags action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)seeTags.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	//Start of user code for other tests
	//End of user code
}