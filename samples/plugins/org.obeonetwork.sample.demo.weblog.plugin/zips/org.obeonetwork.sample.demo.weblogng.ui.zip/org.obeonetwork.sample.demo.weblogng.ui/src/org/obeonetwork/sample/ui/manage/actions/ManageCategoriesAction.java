package org.obeonetwork.sample.ui.manage.actions;

// Start of user code for import
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.obeonetwork.sample.ui.manage.forms.ManageCategoriesForm;


import org.obeonetwork.sample.manage.IManageService;
import org.obeonetwork.sample.monitor.IMonitorService;


// End of user code for import


/**
 * Implementation of <strong>ManageCategories Action</strong>
 * Scenario : Manage
 *
 */
public class ManageCategoriesAction extends org.apache.struts.actions.DispatchAction {
    /**
     * Commons Logging instance.
     */
     private final static Log LOG = LogFactory.getLog(ManageCategoriesAction.class);

    /**
     * Forward codes.
     */
	public final static String PAGE_SELF = "self"; //$NON-NLS-1$
	public final static String PAGE_DELETECATEGORY = "deleteCategory"; //$NON-NLS-1$
	public final static String PAGE_REMOVECATEGORY = "removeCategory"; //$NON-NLS-1$
	public final static String PAGE_UPDATECATEGORY = "updateCategory"; //$NON-NLS-1$
	public final static String PAGE_ADDCATEGORY = "addCategory"; //$NON-NLS-1$
	public final static String PAGE_CREATECATEGORY = "createCategory"; //$NON-NLS-1$
//Start of user code user attributes
//End of user code
    /**
     * Process the specified HTTP request for <strong>init</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     * @return Forward setting with indirection forward name (see struts-config for real JSP name)
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward init(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting init");
		String returnCode = PAGE_SELF;
		ManageCategoriesForm manageCategoriesForm = (ManageCategoriesForm)form;

		//Start of user code method init
		// TODO Write here the action code for init
		//End of user code

		LOG.debug("End init");	
		return mapping.findForward(returnCode);
	} 

    /**
     * Process if no event specified. Redirect to init.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     * @return Forward setting with indirection forward name (see struts-config for real JSP name)
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("No event specified. Redirect to init.");
		return init(mapping, form, request, response);
	} 

    /**
     * Process the specified HTTP request for <strong>createCategory</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward createCategory(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting createCategory");
		String returnCode = PAGE_SELF;
		ManageCategoriesForm manageCategoriesForm = (ManageCategoriesForm)form;
		
		//Start of user code method createCategory
		// TODO Write here the action code for createCategory
		//End of user code

		LOG.debug("End createCategory");
		return mapping.findForward(returnCode);
	}
    /**
     * Process the specified HTTP request for <strong>updateCategory</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward updateCategory(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting updateCategory");
		String returnCode = PAGE_SELF;
		ManageCategoriesForm manageCategoriesForm = (ManageCategoriesForm)form;
		
		//Start of user code method updateCategory
		// TODO Write here the action code for updateCategory
		//End of user code

		LOG.debug("End updateCategory");
		return mapping.findForward(returnCode);
	}
    /**
     * Process the specified HTTP request for <strong>deleteCategory</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward deleteCategory(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting deleteCategory");
		String returnCode = PAGE_SELF;
		ManageCategoriesForm manageCategoriesForm = (ManageCategoriesForm)form;
		
		//Start of user code method deleteCategory
		// TODO Write here the action code for deleteCategory
		//End of user code

		LOG.debug("End deleteCategory");
		return mapping.findForward(returnCode);
	}
    /**
     * Process the specified HTTP request for <strong>addCategory</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward addCategory(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting addCategory");
		String returnCode = PAGE_SELF;
		ManageCategoriesForm manageCategoriesForm = (ManageCategoriesForm)form;
		
		//Start of user code method addCategory
		// TODO Write here the action code for addCategory
		//End of user code

		LOG.debug("End addCategory");
		return mapping.findForward(returnCode);
	}
    /**
     * Process the specified HTTP request for <strong>removeCategory</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward removeCategory(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting removeCategory");
		String returnCode = PAGE_SELF;
		ManageCategoriesForm manageCategoriesForm = (ManageCategoriesForm)form;
		
		//Start of user code method removeCategory
		// TODO Write here the action code for removeCategory
		//End of user code

		LOG.debug("End removeCategory");
		return mapping.findForward(returnCode);
	}
    /**
     * Process the specified HTTP request for <strong>viewCategories</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward viewCategories(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting viewCategories");
		String returnCode = PAGE_SELF;
		ManageCategoriesForm manageCategoriesForm = (ManageCategoriesForm)form;
		
		//Start of user code method viewCategories
		// TODO Write here the action code for viewCategories
		//End of user code

		LOG.debug("End viewCategories");
		return mapping.findForward(returnCode);
	}

private IManageService manageService;
public void setManageService(IManageService manageService){
	this.manageService=manageService;
}
private IMonitorService monitorService;
public void setMonitorService(IMonitorService monitorService){
	this.monitorService=monitorService;
}


//Start of user code user methods
//End of user code

}