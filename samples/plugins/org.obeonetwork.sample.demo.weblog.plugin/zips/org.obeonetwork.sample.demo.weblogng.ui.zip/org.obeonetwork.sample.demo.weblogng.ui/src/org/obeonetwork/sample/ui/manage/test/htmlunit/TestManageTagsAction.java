package org.obeonetwork.sample.ui.manage.test.htmlunit;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.List;

import junit.framework.TestCase;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.*;

/**
 * HtmlUnit testing for <strong>ManageTags Form</strong>
 * Scenario : manage
 *
 */
public class TestManageTagsAction extends TestCase {

	/**
	 * initialize the TestCase.
	 * 
	 * @throws Exception if the test fails
	 */
	public void setUp() throws Exception {
		super.setUp();
		//Start of user code for setUp
		//End of user code
	}

	/**
	 * terminate the TestCase.
	 * 
	 * @throws Exception if the test fails
	 */
	public void tearDown() throws Exception {
		super.tearDown();
		//Start of user code for tearDown
		//End of user code
	}

	/**
	 * Constructor
	 */
	public TestManageTagsAction(String testName) {
		super(testName);
		//Start of user code for Constructor
		//End of user code
	}
	/**
	  * Regression test for "createTag" action of class ManageTagsAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageTagscreateTagAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managetags?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageTagsForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput createTag = (HtmlSubmitInput)form.getInputByName("createTag");
	    
	    assertEquals("tagshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for createTag action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)createTag.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "updateTag" action of class ManageTagsAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageTagsupdateTagAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managetags?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageTagsForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput updateTag = (HtmlSubmitInput)form.getInputByName("updateTag");
	    
	    assertEquals("tagshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for updateTag action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)updateTag.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "deleteTag" action of class ManageTagsAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageTagsdeleteTagAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managetags?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageTagsForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput deleteTag = (HtmlSubmitInput)form.getInputByName("deleteTag");
	    
	    assertEquals("tagshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for deleteTag action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)deleteTag.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "addTag" action of class ManageTagsAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageTagsaddTagAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managetags?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageTagsForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput addTag = (HtmlSubmitInput)form.getInputByName("addTag");
	    
	    assertEquals("tagshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for addTag action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)addTag.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "removeTag" action of class ManageTagsAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageTagsremoveTagAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managetags?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageTagsForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput removeTag = (HtmlSubmitInput)form.getInputByName("removeTag");
	    
	    assertEquals("tagshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for removeTag action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)removeTag.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "viewTags" action of class ManageTagsAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageTagsviewTagsAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managetags?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageTagsForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput viewTags = (HtmlSubmitInput)form.getInputByName("viewTags");
	    
	    assertEquals("tagshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for viewTags action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)viewTags.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	//Start of user code for other tests
	//End of user code
}