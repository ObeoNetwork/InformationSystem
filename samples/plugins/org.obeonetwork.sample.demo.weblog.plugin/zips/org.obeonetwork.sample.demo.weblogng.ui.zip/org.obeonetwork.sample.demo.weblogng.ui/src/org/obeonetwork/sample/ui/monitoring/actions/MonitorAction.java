package org.obeonetwork.sample.ui.monitoring.actions;

// Start of user code for import
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import org.obeonetwork.sample.ui.monitoring.forms.MonitorForm;




// End of user code for import


/**
 * Implementation of <strong>Monitor Action</strong>
 * Scenario : Monitoring
 *
 */
public class MonitorAction extends org.apache.struts.actions.DispatchAction {
    /**
     * Commons Logging instance.
     */
     private final static Log LOG = LogFactory.getLog(MonitorAction.class);

    /**
     * Forward codes.
     */
	public final static String PAGE_SELF = "self"; //$NON-NLS-1$
	public final static String PAGE_SEEUSERS = "seeUsers"; //$NON-NLS-1$
	public final static String PAGE_SEECATEGORIES = "seeCategories"; //$NON-NLS-1$
	public final static String PAGE_SEETAGS = "seeTags"; //$NON-NLS-1$
	public final static String PAGE_SEECOMMENTS = "seeComments"; //$NON-NLS-1$
//Start of user code user attributes
//End of user code
    /**
     * Process the specified HTTP request for <strong>init</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     * @return Forward setting with indirection forward name (see struts-config for real JSP name)
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward init(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting init");
		String returnCode = PAGE_SELF;
		MonitorForm monitorForm = (MonitorForm)form;

		//Start of user code method init
		// TODO Write here the action code for init
		//End of user code

		LOG.debug("End init");	
		return mapping.findForward(returnCode);
	} 

    /**
     * Process if no event specified. Redirect to init.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     * @return Forward setting with indirection forward name (see struts-config for real JSP name)
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("No event specified. Redirect to init.");
		return init(mapping, form, request, response);
	} 

    /**
     * Process the specified HTTP request for <strong>seeUsers</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward seeUsers(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting seeUsers");
		String returnCode = PAGE_SELF;
		MonitorForm monitorForm = (MonitorForm)form;
		
		//Start of user code method seeUsers
		// TODO Write here the action code for seeUsers
		//End of user code

		LOG.debug("End seeUsers");
		return mapping.findForward(returnCode);
	}
    /**
     * Process the specified HTTP request for <strong>seeComments</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward seeComments(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting seeComments");
		String returnCode = PAGE_SELF;
		MonitorForm monitorForm = (MonitorForm)form;
		
		//Start of user code method seeComments
		// TODO Write here the action code for seeComments
		//End of user code

		LOG.debug("End seeComments");
		return mapping.findForward(returnCode);
	}
    /**
     * Process the specified HTTP request for <strong>seeCategories</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward seeCategories(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting seeCategories");
		String returnCode = PAGE_SELF;
		MonitorForm monitorForm = (MonitorForm)form;
		
		//Start of user code method seeCategories
		// TODO Write here the action code for seeCategories
		//End of user code

		LOG.debug("End seeCategories");
		return mapping.findForward(returnCode);
	}
    /**
     * Process the specified HTTP request for <strong>seeTags</strong> event.
     * 
     * @param mapping The ActionMapping used to select this instance
     * @param form The optional ActionForm bean for this request (if any)
     * @param request The HTTP request we are processing
     * @param response The HTTP response we are creating
     *
     * @exception Exception if an input/output error or servlet exception occurs
     */
	public ActionForward seeTags(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOG.debug("Starting seeTags");
		String returnCode = PAGE_SELF;
		MonitorForm monitorForm = (MonitorForm)form;
		
		//Start of user code method seeTags
		// TODO Write here the action code for seeTags
		//End of user code

		LOG.debug("End seeTags");
		return mapping.findForward(returnCode);
	}



//Start of user code user methods
//End of user code

}