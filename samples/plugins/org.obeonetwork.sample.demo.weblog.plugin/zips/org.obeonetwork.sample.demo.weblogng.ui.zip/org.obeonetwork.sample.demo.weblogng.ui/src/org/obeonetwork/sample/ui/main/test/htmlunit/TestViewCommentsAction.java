package org.obeonetwork.sample.ui.main.test.htmlunit;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.List;

import junit.framework.TestCase;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.*;

/**
 * HtmlUnit testing for <strong>ViewComments Form</strong>
 * Scenario : main
 *
 */
public class TestViewCommentsAction extends TestCase {

	/**
	 * initialize the TestCase.
	 * 
	 * @throws Exception if the test fails
	 */
	public void setUp() throws Exception {
		super.setUp();
		//Start of user code for setUp
		//End of user code
	}

	/**
	 * terminate the TestCase.
	 * 
	 * @throws Exception if the test fails
	 */
	public void tearDown() throws Exception {
		super.tearDown();
		//Start of user code for tearDown
		//End of user code
	}

	/**
	 * Constructor
	 */
	public TestViewCommentsAction(String testName) {
		super(testName);
		//Start of user code for Constructor
		//End of user code
	}
	/**
	  * Regression test for "addComment" action of class ViewCommentsAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testViewCommentsaddCommentAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/main/viewcomments?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ViewCommentsForm");
		final HtmlTextInput name = (HtmlTextInput)form.getInputByName("name");
		final HtmlTextInput email = (HtmlTextInput)form.getInputByName("email");
		final HtmlTextInput website = (HtmlTextInput)form.getInputByName("website");
		final List content = (List)form.getTextAreasByName("content");
	    final HtmlSubmitInput addComment = (HtmlSubmitInput)form.getInputByName("addComment");
	    
	    assertEquals("commentsnameemailwebsitecontentlog", page1.getTitleText());

		//Start of user code for addComment action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)addComment.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	//Start of user code for other tests
	//End of user code
}