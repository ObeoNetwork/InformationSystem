package org.obeonetwork.sample.ui.manage.test.htmlunit;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.List;

import junit.framework.TestCase;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.*;

/**
 * HtmlUnit testing for <strong>ManageCategories Form</strong>
 * Scenario : manage
 *
 */
public class TestManageCategoriesAction extends TestCase {

	/**
	 * initialize the TestCase.
	 * 
	 * @throws Exception if the test fails
	 */
	public void setUp() throws Exception {
		super.setUp();
		//Start of user code for setUp
		//End of user code
	}

	/**
	 * terminate the TestCase.
	 * 
	 * @throws Exception if the test fails
	 */
	public void tearDown() throws Exception {
		super.tearDown();
		//Start of user code for tearDown
		//End of user code
	}

	/**
	 * Constructor
	 */
	public TestManageCategoriesAction(String testName) {
		super(testName);
		//Start of user code for Constructor
		//End of user code
	}
	/**
	  * Regression test for "createCategory" action of class ManageCategoriesAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageCategoriescreateCategoryAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managecategories?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageCategoriesForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput createCategory = (HtmlSubmitInput)form.getInputByName("createCategory");
	    
	    assertEquals("categorieshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for createCategory action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)createCategory.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "updateCategory" action of class ManageCategoriesAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageCategoriesupdateCategoryAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managecategories?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageCategoriesForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput updateCategory = (HtmlSubmitInput)form.getInputByName("updateCategory");
	    
	    assertEquals("categorieshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for updateCategory action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)updateCategory.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "deleteCategory" action of class ManageCategoriesAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageCategoriesdeleteCategoryAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managecategories?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageCategoriesForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput deleteCategory = (HtmlSubmitInput)form.getInputByName("deleteCategory");
	    
	    assertEquals("categorieshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for deleteCategory action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)deleteCategory.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "addCategory" action of class ManageCategoriesAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageCategoriesaddCategoryAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managecategories?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageCategoriesForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput addCategory = (HtmlSubmitInput)form.getInputByName("addCategory");
	    
	    assertEquals("categorieshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for addCategory action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)addCategory.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "removeCategory" action of class ManageCategoriesAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageCategoriesremoveCategoryAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managecategories?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageCategoriesForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput removeCategory = (HtmlSubmitInput)form.getInputByName("removeCategory");
	    
	    assertEquals("categorieshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for removeCategory action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)removeCategory.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	/**
	  * Regression test for "viewCategories" action of class ManageCategoriesAction
	  * @param Nothing
	  * @return Nothing
	  * @throws Exception
	  */
	public void testManageCategoriesviewCategoriesAction() throws Exception {
	    final WebClient webClient = new WebClient();
	    
	    ResourceBundle r = ResourceBundle.getBundle("tests");
	    final URL url = new URL(r.getString("fr.website.url") + "/pages/manage/managecategories?event=init");
	    final HtmlPage page1 = (HtmlPage)webClient.getPage(url);
	    final HtmlForm form = page1.getFormByName("ManageCategoriesForm");
		final HtmlTextInput hidden = (HtmlTextInput)form.getInputByName("hidden");
		final HtmlTextInput create = (HtmlTextInput)form.getInputByName("create");
		final HtmlTextInput update = (HtmlTextInput)form.getInputByName("update");
		final HtmlTextInput delete = (HtmlTextInput)form.getInputByName("delete");
		final HtmlTextInput add = (HtmlTextInput)form.getInputByName("add");
		final HtmlTextInput remove = (HtmlTextInput)form.getInputByName("remove");
	    final HtmlSubmitInput viewCategories = (HtmlSubmitInput)form.getInputByName("viewCategories");
	    
	    assertEquals("categorieshiddencreateupdatedeleteaddremove", page1.getTitleText());

		//Start of user code for viewCategories action
	    
	    //TODO : initialize form here
	    
	    //Subit the form and get the result page
	    final HtmlPage page2 = (HtmlPage)viewCategories.click();

	    //TODO : validate resulting page
	    
		//End of user code
	}
	//Start of user code for other tests
	//End of user code
}