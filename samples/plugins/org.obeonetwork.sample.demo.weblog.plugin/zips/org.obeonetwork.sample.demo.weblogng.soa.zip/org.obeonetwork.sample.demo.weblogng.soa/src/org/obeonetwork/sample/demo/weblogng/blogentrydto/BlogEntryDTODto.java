package org.obeonetwork.sample.demo.weblogng.blogentrydto;

//Start of user code for import

//End of user code

public class BlogEntryDTODto {
    
}
