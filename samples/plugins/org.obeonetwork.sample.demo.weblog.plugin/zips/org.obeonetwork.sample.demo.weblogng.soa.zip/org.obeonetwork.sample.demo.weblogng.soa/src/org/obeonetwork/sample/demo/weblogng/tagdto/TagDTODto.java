package org.obeonetwork.sample.demo.weblogng.tagdto;

//Start of user code for import

//End of user code

public class TagDTODto {
    
}
