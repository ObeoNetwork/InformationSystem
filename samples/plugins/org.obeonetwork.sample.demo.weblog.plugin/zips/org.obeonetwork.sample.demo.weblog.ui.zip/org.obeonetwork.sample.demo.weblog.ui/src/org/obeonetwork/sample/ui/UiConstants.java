package org.obeonetwork.sample.ui;


public interface UiConstants {
	public final static String CURRENT_USER = "CURRENT_USER";
}
